import io
import logging
import os
import re
import warnings
from pathlib import Path

import joblib
import numpy as np
from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")
app = FastAPI(title="CardioCare")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")


@app.get("/")
def home():
    return FileResponse(ROOT / "static" / "index.html")


def parse_report(text: str) -> dict:
    text = re.sub(r"[\t|]+", " ", text)
    found = {}
    patterns = {
        "age": (r"\b(?:age)\b\s*[:=\-]?\s*(\d{1,3})\b", int, 18, 100),
        "resting_bp": (r"\b(?:resting\s*(?:blood\s*)?pressure|blood\s*pressure|bp)\b\s*[:=\-]?\s*(\d{2,3})\b", int, 80, 200),
        "cholesterol": (r"\b(?:total\s*)?cholesterol\b\s*[:=\-]?\s*(\d{2,3})\b", int, 100, 600),
        "max_hr": (r"\b(?:max(?:imum)?\s*(?:heart\s*rate|hr)|peak\s*heart\s*rate)\b\s*[:=\-]?\s*(\d{2,3})\b", int, 60, 220),
        "oldpeak": (r"\b(?:oldpeak|st\s*depression)\b\s*[:=\-]?\s*(-?\d+(?:\.\d+)?)", float, 0, 6),
    }
    for key, (pattern, cast, low, high) in patterns.items():
        m = re.search(pattern, text, re.I)
        if m:
            value = cast(m.group(1))
            if low <= value <= high:
                found[key] = value
    enums = {
        "sex": (r"\b(?:sex|gender)\b\s*[:=\-]?\s*(male|female|m|f)\b", {"male":"M", "m":"M", "female":"F", "f":"F"}),
        "chest_pain": (r"\b(?:chest\s*pain(?:\s*type)?|pain\s*type)\b\s*[:=\-]?\s*(typical\s*angina|atypical\s*angina|non[- ]?anginal|asymptomatic|ata|nap|asy|ta)\b", {"typicalangina":"TA", "atypicalangina":"ATA", "nonanginal":"NAP", "asymptomatic":"ASY", "ata":"ATA", "nap":"NAP", "asy":"ASY", "ta":"TA"}),
        "ecg": (r"\b(?:resting\s*ecg|ecg)\b\s*[:=\-]?\s*(normal|st|lvh|left\s*ventricular\s*hypertrophy)\b", {"normal":"Normal", "st":"ST", "lvh":"LVH", "leftventricularhypertrophy":"LVH"}),
        "angina": (r"\b(?:exercise[- ]induced\s*)?angina\b\s*[:=\-]?\s*(yes|no|y|n|present|absent)\b", {"yes":"Y", "y":"Y", "present":"Y", "no":"N", "n":"N", "absent":"N"}),
        "st_slope": (r"\b(?:st\s*)?slope\b\s*[:=\-]?\s*(up|upsloping|flat|down|downsloping)\b", {"up":"Up", "upsloping":"Up", "flat":"Flat", "down":"Down", "downsloping":"Down"}),
    }
    for key, (pattern, options) in enums.items():
        m = re.search(pattern, text, re.I)
        if m:
            token = re.sub(r"\s+", "", m.group(1).lower()).replace("-", "")
            found[key] = options.get(token)
    sugar = re.search(r"\b(?:fasting\s*(?:blood\s*)?sugar|fasting\s*glucose|fbs)\b[^\d]{0,24}(\d{2,3})\b", text, re.I)
    if sugar:
        value = int(sugar.group(1))
        if 0 <= value <= 500:
            found["fasting_bs"] = int(value > 120)
    return {k: v for k, v in found.items() if v is not None}


@app.post("/api/report")
async def report(file: UploadFile = File(...)):
    filename = (file.filename or "").lower()
    data = await file.read()
    if len(data) > 12 * 1024 * 1024:
        raise HTTPException(413, "Please upload a report smaller than 12 MB.")
    if filename.endswith(".pdf"):
        try:
            from pypdf import PdfReader
            text = "\n".join(p.extract_text() or "" for p in PdfReader(io.BytesIO(data)).pages)
        except Exception as exc:
            raise HTTPException(400, f"Could not read PDF text: {exc}")
    elif filename.endswith((".txt", ".csv")):
        text = data.decode("utf-8-sig", errors="replace")
    else:
        raise HTTPException(400, "Upload a PDF, TXT, or CSV report.")
    values = parse_report(text)
    return {"values": values, "message": f"Found {len(values)} matching values." if values else "No recognized labels found. Enter values manually."}


class Patient(BaseModel):
    age: int = Field(ge=18, le=100)
    sex: str
    chest_pain: str
    resting_bp: int = Field(ge=80, le=200)
    cholesterol: int = Field(ge=100, le=600)
    fasting_bs: int = Field(ge=0, le=1)
    ecg: str
    max_hr: int = Field(ge=60, le=220)
    angina: str
    oldpeak: float = Field(ge=0, le=6)
    st_slope: str


@app.post("/api/analyze")
def analyze(patient: Patient):
    model = joblib.load(ROOT / "knn_heart_model.pkl")
    scaler = joblib.load(ROOT / "heart_scaler.pkl")
    p = patient.model_dump()
    raw = {"Age": p["age"], "RestingBP": p["resting_bp"], "Cholesterol": p["cholesterol"], "FastingBS": p["fasting_bs"], "MaxHR": p["max_hr"], "Oldpeak": p["oldpeak"], "Sex_" + p["sex"]: 1, "ChestPainType_" + p["chest_pain"]: 1, "RestingECG_" + p["ecg"]: 1, "ExerciseAngina_" + p["angina"]: 1, "ST_Slope_" + p["st_slope"]: 1}
    columns = scaler.feature_names_in_
    frame = np.asarray([[raw.get(column, 0) for column in columns]], dtype=float)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="X does not have valid feature names, but StandardScaler was fitted with feature names")
        scaled = scaler.transform(frame)
    return {"elevated_pattern": int(model.predict(scaled)[0]) == 1}


class ChatRequest(BaseModel):
    messages: list[dict] = Field(min_length=1, max_length=20)


SYSTEM_PROMPT = """You are CardioCare's educational heart-health assistant. Answer questions about heart disease, prevention, symptoms, tests, treatment concepts, and population survival statistics in plain language. Be compassionate, factual, and clear about uncertainty; survival rates depend on diagnosis, stage, treatment, age, and other factors, so never imply a personal prognosis. Do not diagnose, prescribe, change medication, or claim to review a person's records. Encourage users to discuss personal decisions with a clinician. For possible heart attack symptoms (chest pressure/pain, shortness of breath, cold sweat, fainting, or pain spreading to arm/jaw/back) advise calling their local emergency number immediately; do not delay for chat. If asked for an individual treatment or survival prediction, explain that this cannot be determined in chat and direct them to their care team. Keep responses useful and moderate in length."""


@app.post("/api/chat")
def chat(request: ChatRequest):
    api_key = os.getenv("HF_TOKEN")
    if not api_key:
        raise HTTPException(503, "Chat is not configured yet. Add HF_TOKEN to the server environment or .env.")
    try:
        from openai import OpenAI
        safe_messages = []
        for message in request.messages:
            role = message.get("role")
            content = message.get("content")
            if role in ("user", "assistant") and isinstance(content, str):
                safe_messages.append({"role": role, "content": content[:4000]})
        client = OpenAI(base_url="https://router.huggingface.co/v1", api_key=api_key)
        response = client.chat.completions.create(
            model=os.getenv("HF_MODEL", "openai/gpt-oss-120b:fastest"),
            messages=[{"role": "system", "content": SYSTEM_PROMPT}, *safe_messages],
            max_tokens=700,
        )
        return {"answer": response.choices[0].message.content or "I couldn’t form an answer. Please try rephrasing your question."}
    except Exception as exc:
        # Log only the exception category/status; never log request headers or credentials.
        status = getattr(exc, "status_code", None)
        logging.warning("Hugging Face chat request failed (%s; HTTP %s)", type(exc).__name__, status)
        if status == 401:
            detail = "Hugging Face rejected HF_TOKEN. Create a token with Inference Providers permission and update .env."
        elif status == 403:
            detail = "This Hugging Face token or model is not authorized for Inference Providers. Check token permissions and model access."
        elif status == 429:
            detail = "Hugging Face Inference Providers rate limit or credits were reached. Check your account usage and try again later."
        elif status in (400, 404):
            detail = "Hugging Face could not route this model. Check HF_MODEL and model availability in Inference Providers."
        else:
            detail = "Could not reach Hugging Face Inference Providers. Check the server connection and try again."
        raise HTTPException(status if status == 429 else 502, detail)

const form = document.querySelector('#patient-form');
const upload = document.querySelector('#report-file');
const status = document.querySelector('#upload-status');
const result = document.querySelector('#analysis-result');

function setField(name, value) {
  const field = form.elements.namedItem(name);
  if (!field || value === null || value === undefined) return;
  field.value = value;
  field.dispatchEvent(new Event('change', { bubbles: true }));
}

upload.addEventListener('change', async () => {
  const file = upload.files[0];
  if (!file) return;
  status.className = 'inline-status';
  status.textContent = `Reading ${file.name}…`;
  const body = new FormData();
  body.append('file', file);
  try {
    const response = await fetch('/api/report', { method: 'POST', body });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || 'Could not read this report.');
    Object.entries(data.values).forEach(([key, value]) => setField(key, value));
    status.textContent = data.message + (Object.keys(data.values).length ? ' Review the prefilled fields below.' : '');
    if (Object.keys(data.values).length) document.querySelector('.form-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (error) {
    status.className = 'inline-status error';
    status.textContent = error.message;
  }
});

form.addEventListener('submit', async event => {
  event.preventDefault();
  result.innerHTML = '<div class="inline-status">Calculating estimate…</div>';
  const values = Object.fromEntries(new FormData(form));
  for (const key of ['age', 'resting_bp', 'cholesterol', 'fasting_bs', 'max_hr']) values[key] = Number.parseInt(values[key], 10);
  values.oldpeak = Number.parseFloat(values.oldpeak);
  try {
    const response = await fetch('/api/analyze', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(values) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || 'Could not calculate the estimate.');
    result.innerHTML = data.elevated_pattern
      ? '<div class="result-box result-high"><b>Elevated risk pattern</b><p>The model found a pattern associated with elevated cardiovascular risk. Discuss the result with a qualified clinician, who can interpret it alongside your history and examination.</p></div>'
      : '<div class="result-box result-low"><b>Lower risk pattern</b><p>The model did not identify the elevated-risk pattern it was trained to detect. This does not rule out heart disease; discuss symptoms or concerns with a qualified clinician.</p></div>';
  } catch (error) {
    result.innerHTML = `<div class="result-box result-high"><b>Unable to calculate</b><p>${escapeHtml(error.message)}</p></div>`;
  }
});

function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}

const chatForm = document.querySelector('#chat-form');
const chatInput = document.querySelector('#chat-input');
const chatMessages = document.querySelector('#chat-messages');
const conversation = [];

function addMessage(role, text, note = '') {
  const row = document.createElement('div');
  row.className = `message ${role === 'user' ? 'user-message' : 'assistant-message'}`;
  if (role === 'assistant') {
    const avatar = document.createElement('span');
    avatar.className = 'avatar';
    avatar.textContent = '✳';
    row.appendChild(avatar);
  }
  const bubble = document.createElement('div');
  const paragraph = document.createElement('p');
  paragraph.textContent = text;
  bubble.appendChild(paragraph);
  if (note) {
    const small = document.createElement('small');
    small.textContent = note;
    bubble.appendChild(small);
  }
  row.appendChild(bubble);
  chatMessages.appendChild(row);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  return row;
}

async function askQuestion(question) {
  const cleaned = question.trim();
  if (!cleaned) return;
  addMessage('user', cleaned);
  conversation.push({ role: 'user', content: cleaned });
  const pending = addMessage('assistant', 'Thinking…');
  chatInput.disabled = true;
  try {
    const response = await fetch('/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: conversation.slice(-12) })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || 'The assistant could not respond.');
    pending.remove();
    conversation.push({ role: 'assistant', content: data.answer });
    addMessage('assistant', data.answer, 'Educational information · Talk with a clinician about personal decisions');
  } catch (error) {
    pending.remove();
    addMessage('assistant', error.message);
  } finally {
    chatInput.disabled = false;
    chatInput.focus();
  }
}

chatForm.addEventListener('submit', event => {
  event.preventDefault();
  const question = chatInput.value;
  chatInput.value = '';
  askQuestion(question);
});
document.querySelectorAll('[data-question]').forEach(button => button.addEventListener('click', () => askQuestion(button.dataset.question)));
document.querySelector('#clear-chat').addEventListener('click', () => {
  conversation.length = 0;
  chatMessages.innerHTML = '<div class="message assistant-message"><span class="avatar">✳</span><div><p>Hi, I’m here to help explain heart health topics in plain language. What would you like to know?</p><small>Educational information, not personal medical advice</small></div></div>';
});
chatInput.addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    chatForm.requestSubmit();
  }
});

# CardioCare

CardioCare is an educational heart-health web app. It includes report-assisted/manual entry for the existing heart-risk model and an educational heart-health chat powered by Hugging Face Inference Providers.

## Run locally

1. Install Python 3.9 or newer.
2. Install dependencies: `python -m pip install -r requirements.txt`
3. Create a Hugging Face user access token at [Hugging Face token settings](https://huggingface.co/settings/tokens). Use a fine-grained token with **Make calls to Inference Providers** permission.
4. Copy `.env.example` to `.env` and set `HF_TOKEN=your-token`. Keep the token private. You can optionally change `HF_MODEL`; the default is `openai/gpt-oss-120b:fastest`.
5. Start the app: `python heart_disease.py`
6. Open `http://127.0.0.1:8000` in your browser.

The token stays on the server and is excluded from Git. For a GitHub deployment, set `HF_TOKEN` in the hosting provider's encrypted environment settings; never put it in frontend files or commit it. Hugging Face Inference Providers require available account credits/usage, and some providers or models may have additional conditions.

## Deploy on Vercel

Push the project to GitHub and import the repository in Vercel. Vercel detects the FastAPI app in `app.py`; no custom build command is needed. Add `HF_TOKEN` in the Vercel project's Environment Variables and redeploy. Set it for Production and Preview if you want chat in both. Do not commit `.env` or put the token in source code. The app uses Python 3.12.10 and pins scikit-learn 1.8.0 to match the saved model.

The Vercel deployment needs `app.py`, `static/`, `heart_scaler.pkl`, and `knn_heart_model.pkl`; `.vercelignore` excludes local-only files. Hugging Face Inference Providers also requires token permission and available account credits.

Report autofill supports text PDFs, TXT, and CSV. Scanned/image-only PDFs are not OCR processed. The parser only prefills recognized fields; review every value. Values not included in the report remain at the form defaults.

The risk model and chat are educational tools, not diagnostic services. The chatbot cannot estimate an individual's survival or replace a clinician. For possible heart attack symptoms, call your local emergency number.
